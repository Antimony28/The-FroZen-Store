<?php
$server ="localhost";
$user ="root";
$password ="";
$db ="tfs";

$conn = mysqli_connect($server, $user, $password, $db);

if(isset($_POST['submit'])){
    if(!empty($_POST['name']) && !empty($_POST['contact'])  && !empty($_POST['address'])  && !empty($_POST['passwd'])  && !empty($_POST['rePasswd'])){

        $name = $_POST['name'];
        $contact = $_POST['contact'];
        $address = $_POST['address'];
        $password = $_POST['passwd'];
        $rePassword = $_POST['rePasswd'];
    
        if ($password == $rePassword) {

            $sql = "insert into register(name,contact,address,passwd,rePasswd) values('$name','$contact','$address','$password','$rePassword')";

            $run = mysqli_query($conn,$sql);

            if($run && $password == $rePassword){
                echo "Form Submitted Successfully";
            }
            
        }
        else{
            echo "Form Not Submitted Successfully. Your password does not match. Try again";
        }
    }

    else{
        echo " all fields are required ";
    }
}
?>