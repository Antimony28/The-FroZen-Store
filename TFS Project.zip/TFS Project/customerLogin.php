<!DOCTYPE html>
<html>
<head>
	<title> Login Form in HTML5 and CSS3</title>
	<link rel="stylesheet" href="customer.css">
</head>
<body>
    <header>
            <a class="logo" href="/"><img src="banner.png" width="300" height="70" alt="logo"></a>
            <a class="logo2" href="voice.html"><img src="mic.png" width="40" height="40" alt="logo2"></a>
            
            <nav>
                
                <ul class="nav__links">
                    
                    <li><a href="#">Our Menu</a></li>

                    <li><a href="#">Everyday Value</a></li>

                    <li><a href="#">Stores</a></li>

                    <li><a href="#">Contact Us</a></li>
                </ul>
            </nav>
            <a class="cta" href="homePage.html" target="_blank" >Home</a>
            
        </header>
	<div class="container">
	<!-- <img src=""/> -->
		<form action="custConfig.php" method="POST">
            <img src="logos/clb.png" width="12px" height="5px">
			<div class="form-input">
                <!-- <img src="" > -->
				<input  type="text" name="contact" placeholder="Enter your Contact Number"/>	
			</div>
			<div class="form-input">
                <!-- <img src="" width="" height=""> -->
				<input type="password" name="passwd" placeholder="Enter your password"/>
			</div>
			<button type="submit" name="submit" class="btn-login">Login</button>
		</form>
            <br>
            <a style="text-align: right;" href="register.php" target="_blank"> 

            <input type="submit" type="submit" value="New User?" class="btn-login"/></a>
	</div>
</body>
</html>

