<!DOCTYPE html>
<html>
    <head>
        <title> Login Form in HTML5 and CSS3</title>
        <link rel="stylesheet" href="register.css">
        <script>

            window.addEventListener("load", function () {

                const loader = document.querySelector(".loader");

                loader.className += " hidden"; // class "loader hidden"
            });

        </script>
    
    
        <body>
            <header>
                    <a class="logo" href="/"><img src="banner.png" width="300" height="70" alt="logo"></a>
                    <a class="logo2" href="voice.html"><img src="mic.png" width="40" height="40" alt="logo2"></a>
                    
                    <nav>
                        
                        <ul class="nav__links">
                            
                            <li><a href="#">Our Menu</a></li>

                            <li><a href="#">Everyday Value</a></li>

                            <li><a href="#">Stores</a></li>

                            <li><a href="#">Contact Us</a></li>
                        </ul>
                    </nav>
                    <a class="cta" href="homePage.html" >Home</a>
                    
                </header>

                <div class="loader">

                    <img src="load.gif" alt="Loading..." >

                </div>
            <div class='container'> 
            <img src="logos/clb.png">
                <form action="regConfig.php" method="POST">
                <div class="form-input">
                        
                        <input type="text" name="name" placeholder="Enter your Name"/>	
                    </div>
                    <div class="form-input">
                        
                        <input type="text" name="contact" placeholder="Enter your Contact Number"/>	
                    </div>
                    <div class="form-input">
                        
                        <input type="text" name="address" placeholder="Enter your Address"/>
                    <div class="form-input">
                        
                        <input type="password" name="passwd" placeholder="Enter a Password"/>
                    </div>
                    <div class="form-input">
                        
                        <input type="password" name="rePasswd" placeholder="Confirm Password"/>
                        
                    </div>
                    <button type="submit" name="submit" class="btn-login">Register</button>
                </form>
                    
            </div>
        </body>
    </head>
</html>