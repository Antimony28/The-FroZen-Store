<?php
$server ="localhost";
$user ="root";
$password ="";
$db ="tfs";

$conn = mysqli_connect($server, $user, $password, $db);

if(isset($_POST['submit'])){
    if(!empty($_POST['cardno']) && !empty($_POST['expire'])  && !empty($_POST['cvv'])  && !empty($_POST['name'])){

        $cardno = $_POST['cardno'];
        $expire = $_POST['expire'];
        $cvv = $_POST['cvv'];
        $name = $_POST['name'];

        $sql = "insert into carddetails(cardnumber, expiry, cvv, name) values('$cardno','$expire','$cvv','$name')";

        $run = mysqli_query($conn,$sql);

        if($run){
            echo "Payment Successful.";
        }
            
        
        else{
            echo "Payment Failed." .mysqli_error($conn);
        }
    }

    else{
        echo " Enter Details properly ";
    }
    
}

?>