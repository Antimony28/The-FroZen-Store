<?php
$server ="localhost";
$user ="root";
$password ="";
$db ="tfs";

$conn = mysqli_connect($server, $user, $password, $db);

if(isset($_POST['submit'])){
    if(!empty($_POST['contact']) && !empty($_POST['passwd'])){

        $contact = $_POST['contact'];
        $password = $_POST['passwd'];

        $check = "select contact from register where contact = '$contact'";
        $retrive = mysqli_query($conn, $check);

        if (!$retrive) {
            die ("User not found. Please register");
        }
        else {

            $sql = "insert into customerlogin(contact,passwd) values( '$contact','$password')";

            $run = mysqli_query($conn,$sql);

            if($run){
                echo "Form Submitted Successfully";
            }
            else{
                echo "Form Not Submitted Successfully" .mysqli_error($conn);
            }
        }
    }

    else{
        echo " all fields are required ";
    }
}
?>