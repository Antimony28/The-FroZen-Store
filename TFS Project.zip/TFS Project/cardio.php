<!DOCTYPE html>
<html>
    <head>
        <title> Payment</title>
        <link rel="stylesheet" href="register.css">
        <script>

            window.addEventListener("load", function () {

                const loader = document.querySelector(".loader");

                loader.className += " hidden"; // class "loader hidden"
            });

        </script>
    
    
        <body>


            <div class="loader">

            <img src="load.gif" alt="Loading..." >

            </div>
            <div class='container'> 
            <img src="logos/clb.png">
            <form action="cardioConfig.php" method="POST">
            <div class="form-input">
                
                <input type="text" name="cardno" placeholder="Enter your Card Number"/>	
            </div>
            <div class="form-input">
                
                <input type="text" name="expire" placeholder="Enter your card's exipry date"/>	
            </div>
            <div class="form-input">
                
                <input type="password" name="cvv" placeholder="Enter your CVV"/>
            <div class="form-input">
                
                <input type="text" name="name" placeholder="Enter your name"/>
            </div>
            
            <button type="submit" name="submit" class="btn-login">Proceed</button>
            </form>

            </div>
        </body>
    </head>
</html>